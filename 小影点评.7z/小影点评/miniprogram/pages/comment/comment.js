// pages/comment/comment.js
//6.1：初始化数据 env 是相应的云数据库的环境id
const db = wx.cloud.database({
  env: "web-test-01-rvddd"
})
Page({

  /**
* 页面的初始数据
   */
  data: {
    value: "", //输入框中用户输入内容
    score: 5, //默认打五分满分
    movieid: 0,  //电影id值
    details: {}, //保存电影信息
    images: [],  //保存选中图片
    fileIDS: [],//上传成功，保存fileID
  },
  mysubmit: function () {
    //功能：将选中的图片上传到云存储中
    //功能：将云存储中的fileID一次性保存到云数据集合中
    //1：在data中添加属性fileIDS:[]
    //2：显示加载动画提示框 “正在提交中”
    wx.showLoading({
      title: '正在提交中...',
    })
    //3：上传到云存储
    //3.1：创建数组promise[保存promise对象]
    var promiseArr = [];
    //3.2：创建一个循环，遍历选中的图片
    for (var i = 0; i < this.data.images.length; i++) {
      //3.3：创建promise对象
      promiseArr.push(new Promise((resolve, reject) => {
        //3.3.1：获取当前图片
        var item = this.data.images[i];
        //3.3.2：创建一个正则表达式，拆分文件后缀名 .jpg .gif .pn
        var suffix = /\.\w+$/.exec(item)[0];
        //3.3.3：上传图片并且将fileID保存数组
        //新文件名=时间+随机数+后缀
        var newFile = new Date().getTime() + Math.floor(Math.random() * 9999) + suffix;
        wx.cloud.uploadFile({
          cloudPath: newFile,//新文件名
          filePath: item,//选中文件
          success: res => {//上传成功
            //3.3.5：长传成功拼接fileID
            var fid = res.fileID;
            var ids = this.data.fileIDS.concat(fid)
            this.setData({
              fileIDS: ids
            })
            console.log("上传成功", res);
            //3.3.6：将当前promise任务追加任务列表中
            resolve();
            //3.3.7：上传失败输出错误信息
          },
          fail: err => {//上传失败
            console.log(err);
          }
        })
      }));//promise end  
    }//for end

    Promise.all(promiseArr).then(res => {
      db.collection("comment")//指定集合
        .add({                  //添加记录
          data: {                //数据
            content: this.data.value,           //评论内容
            score: this.data.score,             //评论分数
            movieid: this.data.movieid,           //电影id
            fileIDS: this.data.fileIDS             //图片fileID
          }
        }).then(res => {
          //8：隐藏加载提示框
          wx.hideLoading();
          //9：显示提示框 “发表成功”
          wx.showToast({ title: "发表成功" })
        }).catch(err => {
          //10：添加集合失败
          //11：隐藏加载提示框
          wx.hideLoading();
          //12：显示提示框“评论失败”
          wx.showToast({ title: '发表失败', })
        })
    })
  },
  selectImge: function () {
    //:功能:请用户选中9张图片并且保存data中
    //1:在data添加数组属性 images
    wx.chooseImage({
      count: 9,
      sizeType: ["original", "compressed"],
      sourceType: ["album", "camera"],
      success: (res) => {
        var files = res.tempFilePaths;
        //2:调用wx.chooseImage选中图片

        //3:将选中9张图片images中
        this.setData({
          images: files
        })
      },
    })
  },
  loadMore: function () {
    //功能：发送请求获取云函数返回数据
    //1：接收电影列表传递参数id
    var id = this.data.movieid;
    console.log(id);//26794435
    //2：显示数据加载提示框
    wx.showLoading({
      title: '加载中...',
    })
    //3：调用云函数
    wx.cloud.callFunction({   //调用云函数
      name: "getDetail2",    //云函数名
      data: { id: id }         //参数
    }).then(res => {          //调用成功

      //4：获取云函数返回结果
      //4.1：将云函数返回的字符串转为js对象
      var obj = JSON.parse(res.result);
      //4.2：保存js对象detail
      this.setData({
        detail: obj,
      })
      //4.3：隐藏加载提示框
      wx.hideLoading();
    }).catch(err => {         //调用失败
      console.log(err);
    })

  },
  onContentChange: function (e) {
    this.setData({
      value: e.detail
    })
  },
  onScoreChange: function (e) {
    //用户打分对应事件处理函数
    //1：获取用户现在输入分数
    //2：将用户输入新分数赋值操作
    this.setData({
      score: e.detail
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);//{id: "26794435"}
    //将电影列表组件传递参数id保存在data中movieid
    this.setData({
      movieid: options.id
    });
    this.loadMore();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})