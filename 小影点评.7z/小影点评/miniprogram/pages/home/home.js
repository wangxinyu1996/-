// pages/home/home.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 3:保存的数据
    list: [],
    focus: false,
    inputValue: ''
  },
  bindButtonTap: function () {
    this.setData({
      focus: true
    })
  },
  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  bindReplaceInput: function (e) {
    var value = e.detail.value
    var pos = e.detail.cursor
    if (pos != -1) {
      //光标在中间
      var left = e.detail.value.slice(0, pos)
      //计算光标的位置
      pos = left.replace(/11/g, '2').length
    }
    //直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos
    }
    //或者直接返回字符串,光标在最后边
    //return value.replace(/11/g,'2'),
  },
  
  jumpComment:function(e){
    //功能:用户点击详情按钮后跳转详情组件
    //     comment
    //保留并跳转,允许回退
    //获取自定义的属性
    var id=e.target.dataset.id;
    wx.navigateTo({
      url:'/pages/comment/comment?id='+id,
    });

  },

  loadMore: function () {
    // console.log(123)
    // 1:调用我们的云函数
    wx.cloud.callFunction({
      name: "movielist2",
      data: {
        start: this.data.list.length, count: 10
      }
    }).then(res => {
      // console.log(res,"请求成功")
      //将返回的字符串转为对象
      var obj = JSON.parse(res.result);
      console.log(obj)
      //保存电影列表
      // 1.10：保存电影列表列表数据
      var rows = obj.subjects;
      // 1.11：将电影列表数据组拼接操作
      rows = this.data.list.concat(rows);
      // 1.12：将拼接后结果保存起来


      this.setData({
        // list:obj.subjects原来第一页的数据
        list: rows/*第二页++好多数据 */
      })
      // 1:接收返回数据list
      // 2：在home.wxml创建循环
      // 3：遍历电影信息
      // 4：电影图片 small
      // 5:电影标题
      // 6：电影评分
      // 7：电影导演
      // 8：电影年份
      // 9：电影主演
    }).catch(err => { console.log(err, "请求失败") })
    // 2：将返回的结果保存起来(list)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadMore();
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {


  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {


  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {


  },


  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log(123);
    // 发送请求下载下一页数据
    this.loadMore();
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {


  }
})