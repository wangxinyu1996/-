// pages/mymovie/mymovie.js
//初始化数据库并且指定环境id
const db = wx.cloud.database({
  env:"web-test-01-rvddd"
})
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content:"",//用户输入文字
    file:{}    //选中图片
  },
  myupload:function(){
    //功能1:选择一张图片
    //console.log(123);
    wx.chooseImage({                      //选中图片
      count: 1,                           //选中一张图片
      sizeType:["original","compressed"], //图片类型 原图压缩图
      sourceType:["album","camera"],      //图片来源相册 相机
      success: (res)=>{            
      //获取选中图片
      var file = res.tempFilePaths[0];
      //将选中图片保存data
      //1:在data添加属性 file 表示选中文件
      //2:将选中图片保存
      this.setData({
        file:file
      })
      },
    })
  },
  mysubmit:function(){
    //功能2:上传图片并且将图片保存云函数
    // console.log(456);
    //1:获取上传图片
    var f = this.data.file;
    //2:截取文件后缀后名称
    var suffix = /\.\w+$/.exec(f)[0];
    //3:创建新文件名称
    var newFile = new Date().getTime()+suffix;
    //4:获取用户评论内容
    var c = this.data.content;
    //5:上传文件操作
    //5.1:如果上传成功
    wx.cloud.uploadFile({       //上传
      cloudPath: newFile,       //新文件名
      filePath: f,              //选中文件
      success: res => {         //上传成功
        //console.log(res.fileID)
        //5.1.2:在程序开始声明数据库
        var fId = res.fileID;
        //5.3:将fileID评论内容添加数据库中
        //5.4:提示发表成功提示框
        db.collection("mymovie")
          .add({                              //向集合中添加数据
            data: { fileId: fId, content: c }
          })
          .then(res => {
            console.log(res);
            wx.showToast({
              title: '发表成功',
            })
          })
          .catch(err => {
            console.log(err);
            wx.showToast({
              title: '发表失败',
            })
          })
      },
      fail: err => {                          //上传失败


      }
      })
      //5.2:获取fileID
      //5.3:将fileID评论内容添加到数据库中
      //5.4:提示发表成功提示框
  },
  onContentChange:function(e){
    //功能:获取用户输入留言内容
    this.setData({
      content: e.detail
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})