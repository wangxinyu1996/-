//云函数 movielist3 次函数功能：向豆瓣网发送请求，获取最新热映的电影列表
//1：引入第三方ajax库 request-promise
var rp = require("request-promise")
//2：创建main函数
exports.main = async (event, context) => {
  //3：创建变量url 请求地址
  var url = `http://api.douban.com/v2/movie/in_theaters?apikey=0df993c66c0c636e29ecbb5344252a4a&start=${event.start}&count=${event.count}`
  //4：请求rp函数发送请求并且将豆瓣返回
  //电影列表返回调用者
  return rp(url).then(res => {
    return res;
  }).catch(err => {
    console.log(err);
  })
}