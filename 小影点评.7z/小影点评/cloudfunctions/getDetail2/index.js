// 云函数入口文件
/*const cloud = require('wx-server-sdk')


cloud.init()const cloud = require('wx-server-sdk')


cloud.init()


// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()


  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}*/
//功能发送ajax请求获取豆瓣电影的详情
//引入ajax的库
var rq = require("request-promise")
// 创建main函数
exports.main = async (event, context) => {
  // 向豆瓣网发送请求
  var url = `http://api.douban.com/v2/movie/subject/${event.id}?apikey=0df993c66c0c636e29ecbb5344252a4a`;
  // 返回带着豆瓣电影的详情内容
  return rq(url)//返回url
    .then(res => {//返回成功
      return res
    }).catch(err => {//返回失败
      console.log(err)
    })
}